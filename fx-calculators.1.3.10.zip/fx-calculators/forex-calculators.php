<?php

/**
 * Forex Calculators
 *
 * @package forex-calculators
 * @author  Levan Tarbor 
 *
 * @wordpress-plugin
 * Plugin Name:       Forex Calculators
 * Description:       Adds Useful Forex Calculators To Your Webpage.
 * Version:           1.3.10
 * Author:            Levan Tarbor
 * Author URI:        https://tarbor.me/about/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       forex-calculators
 */

defined('ABSPATH') or die;

require 'functions.php';

class ForexCalculatorsPlugin
{
  public $plugin_dirname;
  public $plugin_basename;

  function __construct()
  {
    $this->plugin_basename = plugin_basename(__FILE__);
    $this->plugin_dirname = dirname($this->plugin_basename);
    $this->init();
  }

  function init()
  {
    add_action('admin_menu', array($this, 'admin_menu_page'));
    add_action('init', array($this, 'add_shortcodes'));
  }

  function add_shortcodes()
  {
    add_shortcode('fxcalc_margin', array($this, 'add_margin_shortcode'));
    add_shortcode('fxcalc_pipvalue', array($this, 'add_pipvalue_shortcode'));
    add_shortcode('fxcalc_profit', array($this, 'add_profit_shortcode'));
    add_shortcode('fxcalc_lotsize', array($this, 'add_lotsize_shortcode'));
    add_shortcode('fxcalc_rrwinrate', array($this, 'add_rrwinrate_shortcode'));
  }

  function add_margin_shortcode()
  {
    return $this->add_shortcode('margin');
  }

  function add_pipvalue_shortcode()
  {
    return $this->add_shortcode('pipvalue');
  }

  function add_profit_shortcode()
  {
    return $this->add_shortcode('profit');
  }

  function add_lotsize_shortcode()
  {
    return $this->add_shortcode('lotsize');
  }

  function add_rrwinrate_shortcode()
  {
    return $this->add_shortcode('rrwinrate');
  }

  function add_shortcode($type)
  {
    return fxcalc_iframe_tag($type);
  }

  function register()
  {
    $this->register_assets();

    add_filter('plugin_action_links_' . $this->plugin_basename, array($this, 'settings_link'));

    register_activation_hook(__FILE__, array($this, 'activate'));
    register_deactivation_hook(__FILE__, array($this, 'deactivate'));

    add_action('admin_init', array($this, 'register_settings'));
    add_action('admin_init', array($this, 'check_installation_time'));
    add_action('admin_init', array($this, 'spare_me'));
    add_action('wp_ajax_fxcalc_settings', array($this, 'ajax_settings_callback'));
    add_action('admin_notices', array($this, 'settings_admin_notices'));
  }

  function ajax_settings_callback()
  {
    if (is_admin() && wp_doing_ajax()) {
      // Verify nonce
      if (!isset($_POST['fxcalc_nonce']) || !wp_verify_nonce($_POST['fxcalc_nonce'], 'fxcalc_settings_nonce')) {
        wp_send_json_error('Invalid nonce');
        return;
      }
      
      // Add capability check
      if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized access');
        return;
      }
      
      $calculator = sanitize_text_field($_POST["calculator"]);
      $settings_key = 'fxcalc_' . $calculator . '_settings';
      
      // Validate calculator name
      if (!in_array($calculator, ['margin', 'pipvalue', 'lotsize', 'profit', 'rrwinrate'])) {
        wp_send_json_error('Invalid calculator type');
        return;
      }

      // Get and sanitize settings
      $settings = [];
      if (isset($_POST[$settings_key]) && is_array($_POST[$settings_key])) {
        foreach ($_POST[$settings_key] as $key => $value) {
          // Handle arrays (like ads settings)
          if (is_array($value)) {
            $settings[$key] = array_map('sanitize_text_field', $value);
          } else {
            $settings[$key] = sanitize_text_field($value);
          }
        }
      }

      update_option($settings_key, $settings);
      wp_send_json_success(array_merge($settings, array('calculator' => $calculator)));
    }
  }

  function settings_link($links)
  {
    $settings_link = '<a href="admin.php?page=' . $this->plugin_dirname . '/admin-page.php">Settings</a>';
    return array_merge([$settings_link], $links);;
  }

  function check_installation_time()
  {
    $install_date = get_option('fxcalc_activation_time', strtotime('-8 days'));
    $past_date = strtotime('-7 days');
    $spare_me = get_option('fxcalc_spare_me', FALSE);

    if ($past_date >= $install_date && !$spare_me) {
      add_action('admin_notices', array($this, 'display_review_notices'));
    }
  }

  function grid_display_admin_notice()
  {
    global $pagenow;
    if ($pagenow == 'index.php') {
      $plugin_info = get_plugin_data(__FILE__, true, true);
      $plugin_name = isset($plugin_info['Name']) ? sanitize_text_field($plugin_info['Name']) : 'Forex Calculators';
      $reviewurl = 'https://wordpress.org/support/plugin/' . sanitize_title($plugin_name) . '/reviews/';

      printf(
        wp_kses(
          /* translators: 1: Plugin name, 2: Review URL */
          esc_html__('<div class="fxcalc-review wrap">You have been using <b> %1$s </b> for a while. We hope you liked it ! Please give us a quick rating, it works as a boost for us to keep working on the plugin !<div class="fxcalc-review-btn"><a href="%2$s" class="button button-primary" target="_blank">Rate Now!</a></div></div>', 'forex-calculators'),
          array(
            'div' => array('class' => array()),
            'b' => array(),
            'a' => array('href' => array(), 'class' => array(), 'target' => array())
          )
        ),
        esc_html($plugin_name),
        esc_url($reviewurl)
      );
    }
  }

  function display_review_notices()
  {
    global $pagenow;
    $spare = !get_option('fxcalc_spare_me', FALSE);
    if ($pagenow == 'index.php' && !$spare) {
      $dont_disturb = get_admin_url() . '?fxcalc_spare_me=1';
      $plugin_info = get_plugin_data(__FILE__, true, true);
      $reviewurl = 'https://wordpress.org/support/plugin/forex-calculators/reviews/';

      /* translators: 1: Plugin name, 2: Review URL, 3: Don't disturb URL */
      printf(esc_html__('<div class="notice notice-success is-dismissible fxcalc-review wrap"><p>You have been using <b> %1$s </b> for a while. We hope you liked it ! Please give us a quick rating, it works as a boost for us to keep working on the plugin !</p><p class="fxcalc-review-btn"><a href="%2$s" class="button button-primary" target="_blank">Rate Now!</a><a href="%3$s" class="button fxcalc-ms"> Already Done !</a></p></div>', 'forex-calculators'), 
          esc_html($plugin_info['Name']), 
          esc_url($reviewurl), 
          esc_url($dont_disturb)
      );
    }
  }

  function spare_me()
  {
    if (!empty($_GET['fxcalc_spare_me'])) {
      $spare_me = $_GET['fxcalc_spare_me'];
      if (intval($spare_me) == 1) {
        add_option('fxcalc_spare_me', TRUE);
      }
    }
  }

  function register_assets()
  {
    add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    add_action('wp_enqueue_scripts', array($this, 'enqueue_wp_assets'));
  }

  function admin_menu_page()
  {
    add_menu_page(
      'Forex Calculators Settings',
      'Forex Calculators',
      'manage_options',
      $this->plugin_dirname . '/admin-page.php',
      '',
      'dashicons-calculator',
      6
    );
  }

  function enqueue_admin_assets()
  {
    wp_enqueue_style('fxcalc_admin_style', $this->assets_url('styles.min.css'), array(), '1.3.10');
    wp_enqueue_script('fxcalc_admin_script', $this->assets_url('loader.min.js'), array(), '1.3.10');
  }

  function enqueue_wp_assets()
  {
    wp_enqueue_style('fxcalc_wp_style', $this->assets_url('styles.min.css'), array(), '1.3.10');
    wp_enqueue_script('fxcalc_wp_script', $this->assets_url('loader.min.js'), array(), '1.3.10');
  }

  function activate()
  {
    flush_rewrite_rules();
    $get_activation_time = strtotime("now");
    add_option('fxcalc_activation_time', $get_activation_time);
  }

  function deactivate()
  {
    flush_rewrite_rules();
  }

  function assets_url($filename)
  {
    return plugins_url('/assets/minified/' . $filename, __FILE__);
  }

  function fxcalc_settings_validate($args, $calculator)
  {
    $style_mode_error = true;
    $title_error = true;
    $title_alignment_error = true;

    $sk = 'fxcalc_' . $calculator . '_style_mode';
    $tk = 'fxcalc_' . $calculator . '_title';
    $ak = 'fxcalc_' . $calculator . '_title_alignment';

    $style_mode_error = $style_mode_error && !isset($args[$sk]);
    $title_error = $title_error && !isset($args[$tk]);
    $title_alignment_error = $title_alignment_error && !isset($args[$ak]);

    if ($style_mode_error) {
      add_settings_error('fxcalc_' . $calculator . '_settings', 'fxcalc_style_mode_required', 'Please select a style mode for the calculator!', $type = 'error');
    }

    if ($title_error) {
      add_settings_error('fxcalc_' . $calculator . '_settings', 'fxcalc_title_required', 'Please select a title option for the calculator!', $type = 'error');
    }

    if ($title_alignment_error) {
      add_settings_error('fxcalc_' . $calculator . '_settings', 'fxcalc_title_alignment_required', 'Please select a title alignment for the calculator!', $type = 'error');
    }

    return $args;
  }

  function fxcalc_margin_settings_validate($args)
  {
    return $this->fxcalc_settings_validate($args, 'margin');
  }

  function fxcalc_pipvalue_settings_validate($args)
  {
    return $this->fxcalc_settings_validate($args, 'pipvalue');
  }

  function fxcalc_profit_settings_validate($args)
  {
    return $this->fxcalc_settings_validate($args, 'profit');
  }

  function fxcalc_lotsize_settings_validate($args)
  {
    return $this->fxcalc_settings_validate($args, 'lotsize');
  }

  function fxcalc_rrwinrate_settings_validate($args)
  {
    return $this->fxcalc_settings_validate($args, 'rrwinrate');
  }

  function register_settings()
  {
    $calculators = array('margin', 'pipvalue', 'lotsize', 'profit', 'rrwinrate');
    foreach ($calculators as $calculator) {
      register_setting(
        'fxcalc_' . $calculator . '_settings',
        'fxcalc_' . $calculator . '_settings',
        array($this, 'fxcalc_' . $calculator . '_settings_validate')
      );
    }
  }

  function settings_admin_notices()
  {
    settings_errors();
  }
}

if (class_exists('ForexCalculatorsPlugin')) {
  $forexCalculatorsPlugin = new ForexCalculatorsPlugin();
  $forexCalculatorsPlugin->register();
}
