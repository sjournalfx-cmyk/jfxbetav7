const path = require('path');

module.exports = {
    entry: [
        __dirname + '/assets/src/loader.js',
        __dirname + '/assets/src/styles.scss'
    ],
    output: {
        path: path.resolve(__dirname, 'assets/minified'), 
        filename: 'loader.min.js',
    },
    module: {
        rules: [
            {
                test: /\.(?:js|mjs|cjs)$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: [
                            ['@babel/preset-env', { targets: "ie 11" }]
                        ]
                    }
                }
            }, {
                test: /\.scss$/,
                exclude: /node_modules/,
                use: [
                    {
                        loader: 'file-loader',
                        options: { outputPath: '/', name: '[name].min.css'}
                    },
                    'sass-loader'
                ]
            }
        ]
    },
};