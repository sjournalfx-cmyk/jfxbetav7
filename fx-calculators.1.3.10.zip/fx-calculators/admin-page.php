<?php
defined('ABSPATH') or die;

require 'functions.php';

$posts =
  $wpdb->get_results("SELECT * FROM {$wpdb->prefix}posts WHERE (post_type='post' OR post_type='page') AND (
    post_content LIKE '%[fxcalc_margin]%' OR 
    post_content LIKE '%[fxcalc_lotsize]%' OR
    post_content LIKE '%[fxcalc_pipvalue]%' OR 
    post_content LIKE '%[fxcalc_profit]%' OR
    post_content LIKE '%[fxcalc_rrwinrate]%') LIMIT 100");
$counter = 0;

$contents = array(
  'margin' => array(
    'name' => 'Margin',
    'desc' => 'The margin calculator helps with calculating the exact margin needed to open your trading position',
    'titles' => ["Margin calculator", "Forex margin calculator"]
  ),
  'lotsize' => array(
    'name' => 'Lot Size',
    'desc' => 'The lot size(position size) calculator helps with finding the amount of currency units to buy or sell to control your maximum risk per position.',
    'titles' => ["Lot size calculator", "Position size calculator", "Forex risk calculator"]
  ),
  'pipvalue' => array(
    'name' => 'Pip Value',
    'desc' => 'The pip value calculator helps with finding the value of each pip in the currency you want to trade in.',
    'titles' => ["Pip value calculator"]
  ),
  'profit' => array(
    'name' => 'Profit & Loss',
    'desc' => 'The profit & loss calculator helps with finding the potential profits and losses depending on the outcome of the trade.',
    'titles' => ["Profit & loss calculator", "Forex profit & loss calculator", "Forex P/L calculator"]
  ),
  'rrwinrate' => array(
    'name' => 'Risk Reward - Win Rate',
    'desc' => 'This calculator helps with finding minimum risk/reward ratio or win rate to achieve breakeven in trades',
    'titles' => ["Risk/Reward - Win Rate", "R/R - Win Rate Breakeven", "Win rate calculator"]
  ),
);

$ads = array(
  'forex' => array(
    'label' => 'Trade Forex with IFC Markets',
    'link' => 'https://ifcmarkets.click'
  ),
);

?>
<script>
  var fxcalcDbSettings = {};
</script>
<div class="fxcalc-admin">
  <div class="fxcalc-section">
    <div class="fxcalc-section-header">
      <h2>Intro</h2>
    </div>
    <div class="fxcalc-section-body">
      <p>
        <strong>Forex Calculators</strong> plugin is a set of calculators that helps you and your customers
        with measuring profits/losses of each trade, margin that you need for a trade, etc.<br />
        The plugin is made with great care and its totally free of charges.
      </p>
    </div>
  </div>

  <div class="fxcalc-section">
    <div class="fxcalc-section-header">
      <h2>Usage</h2>
    </div>
    <div class="fxcalc-section-body">
      <p>
        Each calculator has its own short code that can be used in your pages/posts.
        At the moment there are five calculators which can be added easily as it's described below.
      </p>
    </div>
  </div>

  <div class="fxcalc-tabs">
    <div class="fxcalc-tabs-header">
      <ul class="fxcalc-tab-items">
        <?php foreach ($contents as $key => $content) { ?>
          <li class="fxcalc-tab-item<?php echo $key === 'margin' ? ' fxcalc-active' : '' ?>">
            <a href="#fxcalc-<?php echo esc_attr($key) ?>-tab" role="button"><?php echo esc_html($content['name']) ?> Calculator</a>
          </li>
        <?php } ?>
      </ul>
    </div>
    <div class="fxcalc-tabs-body">
      <?php foreach ($contents as $key => $content) { ?>
        <div class="fxcalc-tabs-content" id="fxcalc-<?php echo esc_attr($key) ?>-tab" data-id="fxcalc-<?php echo esc_attr($key) ?>-tab" style="display: <?php echo $key === 'margin' ? 'block' : 'none' ?>">
          <form class="fxcalc-settings-form" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" method="post">
            <?php wp_nonce_field('fxcalc_settings_nonce', 'fxcalc_nonce'); ?>
            <div class="fxcalc-row">
              <div class="fxcalc-col-sm">
                <div class="fxcalc-settings-container">
                  <h2>Customize</h2>
                  <hr />
                  <div class="fxcalc-settings">
                    <input type="hidden" name="calculator" value="<?php echo esc_attr($key); ?>" />
                    <input type="hidden" name="action" value="fxcalc_settings" />
                    <?php
                    $options = get_option('fxcalc_' . esc_attr($key) . '_settings');
                    $currentLanguage = isset($options['fxcalc_' . esc_attr($key) . '_language']) ? $options['fxcalc_' . esc_attr($key) . '_language'] : 'en';
                    ?>
                    <script>
                      fxcalcDbSettings['<?php echo esc_js($key); ?>'] = {
                        title: "<?php echo esc_attr(isset($options['fxcalc_' . esc_attr($key) . '_title']) ? $options['fxcalc_' . esc_attr($key) . '_title'] : ''); ?>",
                        language: "<?php echo esc_attr($currentLanguage); ?>",
                        title_alignment: "<?php echo esc_attr(isset($options['fxcalc_' . esc_attr($key) . '_title_alignment']) ? $options['fxcalc_' . esc_attr($key) . '_title_alignment'] : 'left'); ?>",
                        style_mode: "<?php echo esc_attr(isset($options['fxcalc_' . esc_attr($key) . '_style_mode']) ? $options['fxcalc_' . esc_attr($key) . '_style_mode'] : '1'); ?>",
                        esma: "<?php echo esc_attr(isset($options['fxcalc_' . esc_attr($key) . '_esma']) ? $options['fxcalc_' . esc_attr($key) . '_esma'] : ''); ?>",
                        desc: "<?php echo esc_attr(isset($options['fxcalc_' . esc_attr($key) . '_desc']) ? $options['fxcalc_' . esc_attr($key) . '_desc'] : ''); ?>",
                        ads: <?php echo json_encode(isset($options['fxcalc_' . esc_attr($key) . '_ads']) ? $options['fxcalc_' . esc_attr($key) . '_ads'] : array()); ?>
                      };
                    </script>
                    <div class="fxcalc-responsive-group">
                      <div class="fxcalc-form-group">
                        <h3>Language</h3>
                        <div class="fxcalc-select-box-container">
                          <select name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_language]" class="fxcalc-select-language">
                            <option value="en" <?php echo $currentLanguage === "en" ? " selected" : "" ?>>English</option>
                            <option value="ar" <?php echo $currentLanguage === "ar" ? " selected" : "" ?>>Arabic</option>
                            <option value="zh" <?php echo $currentLanguage === "zh" ? " selected" : "" ?>>Chinese</option>
                            <option value="cs" <?php echo $currentLanguage === "cs" ? " selected" : "" ?>>Czech</option>
                            <option value="fr" <?php echo $currentLanguage === "fr" ? " selected" : "" ?>>French</option>
                            <option value="de" <?php echo $currentLanguage === "de" ? " selected" : "" ?>>German</option>
                            <option value="el" <?php echo $currentLanguage === "el" ? " selected" : "" ?>>Greek</option>
                            <option value="hi" <?php echo $currentLanguage === "hi" ? " selected" : "" ?>>Hindi</option>
                            <option value="id" <?php echo $currentLanguage === "id" ? " selected" : "" ?>>Indonesian</option>
                            <option value="it" <?php echo $currentLanguage === "it" ? " selected" : "" ?>>Italian</option>
                            <option value="ja" <?php echo $currentLanguage === "ja" ? " selected" : "" ?>>Japanese</option>
                            <option value="ko" <?php echo $currentLanguage === "ko" ? " selected" : "" ?>>Korean</option>
                            <option value="fa" <?php echo $currentLanguage === "fa" ? " selected" : "" ?>>Persian</option>
                            <option value="pt" <?php echo $currentLanguage === "pt" ? " selected" : "" ?>>Portuguese</option>
                            <option value="ru" <?php echo $currentLanguage === "ru" ? " selected" : "" ?>>Russian</option>
                            <option value="es" <?php echo $currentLanguage === "es" ? " selected" : "" ?>>Spanish</option>
                            <option value="tr" <?php echo $currentLanguage === "tr" ? " selected" : "" ?>>Turkish</option>
                            <option value="vi" <?php echo $currentLanguage === "vi" ? " selected" : "" ?>>Vietnamese</option>
                          </select>
                        </div>
                      </div>

                      <?php
                      $none_checked = !isset($options['fxcalc_' . esc_attr($key) . '_title']) || $options['fxcalc_' . esc_attr($key) . '_title'] == '';
                      $premade_checked = false;
                      ?>
                      <div class="fxcalc-form-group">
                        <h3>Calculator Title</h3>
                        <div class="fxcalc-selectable-items">
                          <div>
                            <label>
                              <input type="radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_title]" value="" <?php echo $none_checked ? 'checked' : ''; ?> />
                              None
                            </label>
                          </div>
                          <?php foreach ($content['titles'] as $title) { ?>
                            <div>
                              <label>
                                <input type="radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_title]" value="<?php echo esc_attr($title) ?>" <?php
                                                                                                                                                                                          if (isset($options['fxcalc_' . esc_attr($key) . '_title']) && strtolower($options['fxcalc_' . esc_attr($key) . '_title']) === strtolower($title)) {
                                                                                                                                                                                            echo 'checked';
                                                                                                                                                                                            $premade_checked = true;
                                                                                                                                                                                          }
                                                                                                                                                                                          ?> />
                                <?php echo esc_html($title) ?>
                              </label>
                            </div>
                          <?php } ?>
                          <div>
                            <label>
                              <input type="radio" class="fxcalc-custom-title-radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_title]" value="" <?php echo (!$premade_checked && !$none_checked ? 'checked' : ''); ?> />
                              <input type="text" class="fxcalc-custom-title" placeholder="Enter custom heading" value="<?php echo esc_attr(!$premade_checked && !$none_checked ? $options['fxcalc_' . esc_attr($key) . '_title'] : "") ?>" />
                            </label>
                          </div>
                        </div>
                        <div class="fxcalc-title-alignments" style="display: <?php echo esc_attr((!isset($options['fxcalc_' . esc_attr($key) . '_title']) || $options['fxcalc_' . esc_attr($key) . '_title'] == '') ? "none" : "flex") ?>">
                          <?php
                          $fxcalc_title_alignment = isset($options['fxcalc_' . esc_attr($key) . '_title_alignment']) && $options['fxcalc_' . esc_attr($key) . '_title_alignment'] != '' ? $options['fxcalc_' . esc_attr($key) . '_title_alignment'] : 'left';
                          ?>
                          <input type="hidden" class="fxcalc_title_alignment" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_title_alignment]" value="<?php echo esc_attr($fxcalc_title_alignment); ?>" />
                          <?php
                          foreach (array('left', 'center', 'right') as $align) {
                          ?>
                            <div class="fxcalc-align fxcalc-align-<?php echo esc_attr($align . ($fxcalc_title_alignment == $align ? ' active' : '')) ?>" data-align="<?php echo esc_attr($align) ?>"><span></span><span></span></div>
                          <?php
                          }
                          ?>
                        </div>

                      </div>
                      <?php
                      if ($key === 'margin') {
                        $esma_checked = !isset($options['fxcalc_' . esc_attr($key) . '_esma']) || $options['fxcalc_' . esc_attr($key) . '_esma'] == '';
                      ?>
                        <div class="fxcalc-form-group">
                          <div class="fxcalc-check-box-container esma-checkbox">
                            <label>
                              <span class="fxcalc-esma-span">ESMA check box</span>
                              <input type="checkbox" class="fxcalc-esma-checkbox" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_esma]" value="1" <?php echo (!$esma_checked ? 'checked' : ''); ?> />
                            </label>
                          </div>
                        </div>
                      <?php
                      }
                      if ($key === 'rrwinrate') {
                        $desc_checked = !isset($options['fxcalc_' . esc_attr($key) . '_desc']) || $options['fxcalc_' . esc_attr($key) . '_desc'] == '';
                      ?>
                        <div class="fxcalc-form-group">
                          <div class="fxcalc-check-box-container desc-checkbox">
                            <label>
                              <span class="fxcalc-desc-span">Description</span>
                              <input type="checkbox" class="fxcalc-desc-checkbox" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_desc]" value="1" <?php echo (!$desc_checked ? 'checked' : ''); ?> />
                            </label>
                          </div>
                        </div>
                      <?php } ?>
                      <div class="fxcalc-form-group">
                        <h3>Style Mode</h3>
                        <div class="fxcalc-styling-options">
                          <div class="fxcalc-styling fxcalc-styling-normal" title="Default mode">
                            <label>
                              <input type="radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_style_mode]" <?php echo (!isset($options['fxcalc_' . esc_attr($key) . '_style_mode']) || $options['fxcalc_' . esc_attr($key) . '_style_mode'] == '1') ? 'checked' : ''; ?> value="1" />
                              Default mode
                            </label>
                            <div onclick="this.parentElement.querySelector('label').click()">
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          </div>
                          <div class="fxcalc-styling fxcalc-styling-double" title="2-column mode">
                            <label>
                              <input type="radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_style_mode]" <?php echo (isset($options['fxcalc_' . esc_attr($key) . '_style_mode']) && $options['fxcalc_' . esc_attr($key) . '_style_mode'] == '2') ? 'checked' : ''; ?> value="2" />
                              Mode 2
                            </label>
                            <div onclick="this.parentElement.querySelector('label').click()">
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          </div>
                          <div class="fxcalc-styling fxcalc-styling-wide" title="Wide mode">
                            <label>
                              <input type="radio" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_style_mode]" <?php echo (isset($options['fxcalc_' . esc_attr($key) . '_style_mode']) && $options['fxcalc_' . esc_attr($key) . '_style_mode'] == '3') ? 'checked' : ''; ?> value="3" />
                              Mode 3
                            </label>
                            <div onclick="this.parentElement.querySelector('label').click()">
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          </div>
                          <span class="fxcalc-mode3-hint fxcalc-<?php echo esc_attr($key) ?>-mode3-hint" style="display: <?php echo esc_attr((isset($options['fxcalc_' . esc_attr($key) . '_style_mode']) && $options['fxcalc_' . esc_attr($key) . '_style_mode'] == '3') ? "block" : "none") ?>">
                            To ensure page responsiveness on small screens,
                            Mode 3 will automatically switch to Mode 2
                          </span>
                        </div>
                      </div>
                    </div>

                    <div class="fxcalc-button-group" data-calculator="<?php echo esc_attr($key); ?>">
                      <input disabled type="submit" class="fxcalc-save-button button button-primary" value="Update short code" />
                    </div>
                    <ol class="fxcalc-tip fxcalc-update-tips" style="display: none">
                      <li>If you want to add the new calculator to new page, you should press "Update short code" first and then press "Copy!" button.</li>
                      <li>If you want to change the appearance of existent calculator/s, just press "Update short code" after new customization.</li>
                    </ol>
                  </div>
                </div>
              </div>
              <div class="fxcalc-col-lg">
                <div class="fxcalc-preview-container">
                  <h2>Preview</h2>
                  <hr />
                  <div class="fxcalc-item-description">
                    <p><?php echo esc_html($content['desc']) ?></p>
                  </div>
                  <div class="fxcalc-item-preview">
                    <?php echo fxcalc_iframe_tag($key); ?>
                  </div>
                  <hr />
                  <div class="fxcalc-item-ads">
                    <p>We would be thankful if you compensate us by displaying the ad under the calculator. Any way you have a choice to hide it.</p>
                    <h3>Ad</h3>
                    <?php
                    foreach ($ads as $ad_key => $ad) {
                      $ad_checked = !isset($options['fxcalc_' . esc_attr($key) . '_ads']) || !in_array($ad_key, $options['fxcalc_' . esc_attr($key) . '_ads']);
                    ?>
                      <div class="switch-container">
                        <a href="<?php echo esc_attr($ad['link']); ?>" target="_blank">
                          <h4><?php echo esc_html($ad['label']); ?></h4>
                        </a>
                        <label class="switch-control">
                          <span class="hide-text">Hide</span>
                          <span class="switch">
                            <input type="checkbox" id="fxcalc-<?php echo esc_attr($key) ?>-ads-<?php echo esc_attr($ad_key); ?>" name="fxcalc_<?php echo esc_attr($key) ?>_settings[fxcalc_<?php echo esc_attr($key) ?>_ads][]" value="<?php echo esc_attr($ad_key); ?>" <?php echo (!$ad_checked ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                          </span>
                          <span class="display-text">Display</span>
                        </label>
                      </div>
                    <?php } ?>
                  </div>
                  <div class="fxcalc-item-shortcode">
                    <div class="fxcalc-shortcode-container">
                      <h4>Short code:</h4>
                      <code>[fxcalc_<?php echo esc_html($key) ?>]</code><button class="fxcalc-copy-code" style="cursor: pointer" data-copy="[fxcalc_<?php echo esc_attr($key) ?>]">Copy!</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      <?php } ?>
    </div>
  </div>

  <div class="fxcalc-section">
    <div class="fxcalc-section-header">
      <h2>Posts/Pages Containing Forex Calculators</h2>
    </div>
    <div class="fxcalc-section-body">
      <?php if (empty($posts)) { ?>
        <p style="color: darkred">
          At the moment, none of your pages/posts are using our calculators. Try adding one :)
        </p>
      <?php } else { ?>
        <table class="fxcalc-posts wp-list-table widefat striped fixed">
          <thead>
            <tr>
              <th>Counter</th>
              <th>Title</th>
              <th>Type</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($posts as $post) { ?>
              <tr>
                <td><?php echo esc_html(++$counter) ?></td>
                <td><a href="<?php echo esc_url(get_edit_post_link($post->ID)) ?>"><?php echo trim($post->post_title) ? esc_attr($post->post_title) : esc_html__('(no title)', 'forex-calculators') ?></a></td>
                <td><?php echo esc_html(ucfirst($post->post_type)) ?></td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      <?php } ?>
    </div>
  </div>

  <div class="fxcalc-footer">
    <p>
      <strong>Let us know please if there is anything:</strong> support@forexcalcs.com
    </p>
  </div>
</div>