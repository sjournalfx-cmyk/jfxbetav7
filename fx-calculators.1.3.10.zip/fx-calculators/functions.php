<?php

defined('ABSPATH') or die;

defined('FXCALC_WEBSITE_ADDRESS') or define('FXCALC_WEBSITE_ADDRESS', 'https://calcs.forexcalcs.com/');

if (!function_exists('fxcalc_iframe_query_string')) {
  function fxcalc_iframe_query_string($style_mode = '1', $title = '', $align = 'left', $primary_color = '#b43cb4', $lang = 'en', $esma = '', $desc = '', $ads = array())
  {
    $queryString = '?pc=' . rawurlencode($primary_color) .
      ($title ? '&title=' . base64_encode($title) : '') .
      '&align=' . rawurlencode($align) .
      '&mode=' . rawurlencode($style_mode) .
      '&lang=' . rawurlencode($lang) .
      ($esma ? '&esma=' . rawurlencode($esma) : '') .
      ($desc ? '&desc=' . rawurlencode($desc) : '');

    foreach ($ads as $ad) {
      $queryString .= '&ads=' . rawurlencode($ad);
    }

    return $queryString;
  }
}

if (!function_exists('fxcalc_iframe_tag')) {
  function fxcalc_iframe_tag($calculator)
  {
    $options = get_option('fxcalc_' . $calculator . '_settings');
    $primary_color = isset($options['fxcalc_primary_color']) ? $options['fxcalc_primary_color'] : '#b43cb4';
    $lang = isset($options['fxcalc_' . $calculator . '_language']) ? $options['fxcalc_' . $calculator . '_language'] : 'en';
    $esma = isset($options['fxcalc_' . $calculator . '_esma']) ? $options['fxcalc_' . $calculator . '_esma'] : '';
    $desc = isset($options['fxcalc_' . $calculator . '_desc']) ? $options['fxcalc_' . $calculator . '_desc'] : '';
    $ads = isset($options['fxcalc_' . $calculator . '_ads']) ? $options['fxcalc_' . $calculator . '_ads'] : array();
    $style_mode = isset($options['fxcalc_' . $calculator . '_style_mode']) ? $options['fxcalc_' . $calculator . '_style_mode'] : '1';
    $title = isset($options['fxcalc_' . $calculator . '_title']) ? $options['fxcalc_' . $calculator . '_title'] : '';
    $align = isset($options['fxcalc_' . $calculator . '_title_alignment']) ? $options['fxcalc_' . $calculator . '_title_alignment'] : 'left';
    $width = (intval($style_mode) == 3 && ($calculator == 'rrwinrate' ? $desc : true)) ? '800' : '484';
    return '<iframe tabindex="-1" data-calculator="' . esc_attr($calculator) . '" data-max-width="' . esc_attr($width) . '" width="' . esc_attr($width) . '" loading="lazy" scrolling="no" class="fxcalc_' . esc_attr($calculator) . '" src="' . esc_attr(FXCALC_WEBSITE_ADDRESS . $calculator . fxcalc_iframe_query_string($style_mode, $title, $align, $primary_color, $lang, $esma, $desc, $ads)) . '"></iframe>';
  }
}
