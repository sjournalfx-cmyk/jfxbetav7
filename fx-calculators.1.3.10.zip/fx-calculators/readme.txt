=== Forex Calculators ===
Contributors: tarborali
Tags: position size,lot size,pip value,margin,forex trading
Tested up to: 6.8.2
Requires at least: 3.0.0
Requires PHP: 5.6
Stable tag: 1.3.10
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


Integrate five essential forex calculators into your site, providing accurate financial analysis for both experienced traders and beginners.

== Description ==

== Plugin Introduction: ==
With the Forex Calculators plugin, seamlessly integrate five essential calculators into your website, offering traders, both experienced and new, a powerful suite of tools for precise and efficient financial analysis. Tailored to the specific needs of forex trading, this plugin stands as a must-have tool for your business. It goes beyond the basics, providing a comprehensive set of calculators that empower users to make well-informed decisions in the dynamic forex market. Whether you're an experienced trader or just starting, the Forex Calculators plugin will bring accuracy and simplicity to your financial calculations. 


== 5 Available Calculators ==
1. **[Lot Size Calculator](https://calcs.forexcalcs.com/lotsize)**: A key tool, also known as the "position size calculator" or "forex risk calculator." This type of calculator helps traders determine trade lot sizes, defining maximum loss in both percentage and deposit currency. By determining the size of a trade, you can specify the maximum loss if the market goes against your trading position direction.

2. **[Pip Calculator](https://calcs.forexcalcs.com/pipvalue)**: An essential tool for calculating the dollar value of pips under various conditions. It adapts to different currency pairs, deposit currencies, and lot sizes, providing tailored insights for decision-making. Simply input some necessary data, such as the currencies you want to trade, the deposit currency, and the lot size. 

3. **[Forex Profit Calculator](https://calcs.forexcalcs.com/profit)**: Easily calculate your potential trade profitability by inputting trade direction, open and close prices, and additional parameters. This calculator offers a detailed analysis of profit and loss scenarios, enriching traders with actionable insights.

4. **[Margin Calculator](https://calcs.forexcalcs.com/margin)**: Vital for online forex trading and CFD markets, determining the minimal deposit amount required for each trade. It features an ESMA checkbox for EU traders to apply area-specific leverage restrictions when calculating margin.

5. **[Risk/Reward – Win Rate Calculator](https://calcs.forexcalcs.com/rrwinrate)**: A unique and rare calculator that empowers traders to assess risk/reward ratios and win rates comprehensively. This calculator provides a nuanced understanding, allowing traders to strategize and find break-even points with precision. You will most probably not find it on the net!


== Why Choose Forex Calculators? ==

* **Currency Pairs, Cryptocurrencies, and More**: Calculators support an array of around 340 currency pairs, alongside silver and gold symbols; anticipate the future with plans for an expanded list of major cryptocurrencies.

* **Live and Editable Rates**: Calculators employ live rates for real-time accuracy in calculations; grant traders the flexibility to customize rates, tailoring the calculations to their unique requirements.

* **Responsive Design**:  The Forex Calculators plugin ensures a seamless and visually pleasing experience across a spectrum of screen sizes, fostering accessibility for a diverse audience. 

* **Multilingual Support**: Forex Calculators covers a wide range of languages, currently working with 18 languages. 

* **Custom Calculator Title**: Customize your calculator titles to easily find the project you need.

* **Vertical and Horizontal Style Modes**: Offers different display styles, either vertical or horizontal, seamlessly integrating with your website's look and feel. 

* **Individual Calculator Settings**: Lets you set distinct settings for each calculator, including language preferences. For example, one calculator can be in English and another one can be in Arabic.


== How to Use: ==
1. Start with **configuration**; modify the plugin settings, tailoring Forex Calculators to your specific needs and requirements.

2. **Short Code Generation**: Activate the "update shortcode" button to customize the appearance of calculators. Effortlessly copy and paste the generated shortcode into any page on your website, with no usage limits.

3. **Modification**: Update the appearance of a calculator across multiple pages by clicking "update short code" after customization.

4. **Deletion**: If you decide to uninstall the plugin, all the shortcodes will be automatically removed from all the pages you put them, eliminating manual interventions.

Experience the simplicity and accuracy of the Forex Calculators plugin, making financial decision-making a breeze for traders navigating the dynamic forex market.


== Who are Forex Calculators For? ==

1. **Forex Traders**: The plugin is tailored to meet the needs of both experienced and new forex traders. It offers a comprehensive suite of calculators to facilitate precise and efficient financial analysis.

2. **Webmasters in Finance Industry**: If you own a website related to finance or forex trading, incorporating the Forex Calculators plugin can enhance the value you provide to your audience. The plugin's seamless integration and customization options make it a valuable addition to financial websites.

3. **Traders Needing Financial Analysis Tools**: Traders who require specific tools for financial analysis for forex trading can benefit from the plugin. The calculators cover essential aspects such as lot size determination, pip calculation, trade profitability assessment, margin requirements, and risk/reward ratio analysis.

4. **Real-time Accuracy Seekers**: Traders who prioritize real-time accuracy in their calculations will find the plugin beneficial. It employs live rates for accurate calculations and allows users to customize rates according to their unique requirements.


== Third-Party Services ==
Forex Calculators relies on a third-party service provided by [forexcalcs.com](https://forexcalcs.com). Based on its terms of use, it is free of charge for non-commercial uses.

**Terms Of Use**: [https://forexcalcs.com/terms-of-use/](https://forexcalcs.com/terms-of-use/)


== Installation ==

= How to install Forex calculators on your Wordpress website =

1. Upload and install Forex Calculators plugin
2. Visit Forex Calculators page in admin menu
3. Copy the short code of the calculator that you want to use
4. Paste where ever you want to let your costumers use the calculator


== ChangeLog ==

= 1.3.10 =
*Release Date - 11 September 2025*

* Tested up to WordPress 6.8.2

= 1.3.9 =
*Release Date - 26 February 2025*

* Plugin Check error fixes

= 1.3.8 =
*Release Date - 26 February 2025*

* Security: Added proper authorization checks for plugin settings
* Security: Enhanced input validation and sanitization

= 1.3.7 =
*Release Date – 24 January 2025*

* Fix possible security issues

= 1.3.6 =
*Release Date – 15 January 2025*

* Tested up to wordpress 6.7.1

= 1.3.5 =
*Release Date – 30 June 2024*

* Update tags

= 1.3.4 =
*Release Date – 30 June 2024*

* Fix plugin name and tags

= 1.3.3 =
*Release Date – 30 June 2024*

* Update plugin descriptions
* Fix responsiveness issues

= 1.3.2 =
*Release Date – 05 April 2024*

* Update plugin descriptions

= 1.3.1 =
*Release Date – 21 February 2024*

* Shorten ad link

= 1.3.0 =
*Release Date – 21 February 2024*

* Risk/Reward – Win Rate Calculator
* Ability to add ESMA rules checkbox
* Multilanguage support
* Set custom title for calculators
* Ability to support our team <3
* Tested up to wordpress 6.4.3

= 1.2.1 =
*Release Date – 28 August 2023*

* Bugfixes and other minor improvements


= 1.2.0 =
*Release Date – 28 August 2023*

* Use ajax to save calculator settings

= 1.1.2 =
*Release Date – 20 August 2023*

* Tested up to wordpress 6.3
* Add some tips to calculator settings
* add style to calculator settings sections

= 1.1.1 =
*Release Date – 30 May 2023*

* Tested up to wordpress 6.2.2
* Better assets versioning
* Fix text directions in rtl websites

= 1.1.0 =
*Release Date – 29 May 2023*

* Updated admin settings
* Added link to plugin's rate & review
* Multiple Styles: Choose between multiple styles to customize the look and feel of your calculators. With a range of styles to choose from, you can find the perfect fit for your needs.
* Add Title to Each Calculator: Now you can add a title to top of each calculator, making it easier to identify.

= 1.0.2 =
*Release Date – 9 Feb 2023*

* Updated descriptions of the plugin.

= 1.0.1 =
*Release Date – 16 Jan 2023*

* The first stable version of Forex calculators plugin


== Screenshots ==
1. Margin calculator screenshot
2. Profit & loss calculator screenshot
3. Lot size calculator screenshot
4. Pip value calculator screenshot
5. Risk reward – win rate calculator screenshot