<?php
defined('WP_UNINSTALL_PLUGIN') or die;

global $wpdb;

$tags = array(
  '[fxcalc_margin]',
  '[fxcalc_lotsize]',
  '[fxcalc_pipvalue]',
  '[fxcalc_profit]',
  '[fxcalc_rrwinrate]'
);
foreach ($tags as $tag) {
  $wpdb->query($wpdb->prepare(
    "UPDATE {$wpdb->prefix}posts SET post_content = REPLACE(post_content, %s, '') WHERE post_content LIKE %s",
    $tag,
    '%' . $wpdb->esc_like($tag) . '%'
  ));
}

flush_rewrite_rules();
