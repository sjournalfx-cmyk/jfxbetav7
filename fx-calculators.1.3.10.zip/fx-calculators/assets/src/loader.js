const SOURCE_URL = 'https://calcs.forexcalcs.com/';
const calculators = ['margin', 'lotsize', 'pipvalue', 'profit', 'rrwinrate'];

function isVisible(elem) {
  return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
}

function respondToVisibility(element, callback) {
  var options = {
    root: document.documentElement,
  };

  var observer = new IntersectionObserver((entries, observer) => {
    let hasInvisibles = false;
    entries.forEach(entry => {
      hasInvisibles = hasInvisibles || !isVisible(entry.target);
      callback(isVisible(entry.target));
    });
    if (hasInvisibles) {
      setInterval(() => {
        entries.forEach(entry => {
          callback(isVisible(entry.target));
        });
      }, 1000);
    }
  }, options);

  observer.observe(element);
}


function copyToClipboard(text) {
  if (window.clipboardData && window.clipboardData.setData) {
    return window.clipboardData.setData("Text", text);
  }
  else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
    var textarea = document.createElement("textarea");
    textarea.textContent = text;
    textarea.style.position = "fixed";
    document.body.appendChild(textarea);
    textarea.select();
    try {
      return document.execCommand("copy");
    }
    catch (ex) {
      console.warn("Copy to clipboard failed.", ex);
      return prompt("Copy to clipboard: Ctrl+C, Enter", text);
    }
    finally {
      document.body.removeChild(textarea);
    }
  }
}

window.onmessage = function (e) {
  if (e.data && typeof e.data === "string" && e.data.startsWith('IFrameSize')) {
    const [, cls, size] = e.data.split('|');
    const iframes = document.querySelectorAll('iframe.fxcalc_' + cls);
    const [width, height] = size.split('X');
    const h = Number(height) + 4;
    iframes.forEach(iframe => {
      iframe.setAttribute('height', h);
    });
  }
};

const initCopyButtons = () => {
  var fxcalc_copiers = document.getElementsByClassName('fxcalc-copy-code');
  for (var fxcalc_c = 0; fxcalc_c < fxcalc_copiers.length; ++fxcalc_c) {
    var fxcalc_copier = fxcalc_copiers[fxcalc_c];
    fxcalc_copier.addEventListener('click', function (e) {
      e.preventDefault();
      const textToCopy = e.target.getAttribute('data-copy');
      copyToClipboard(textToCopy);
      e.target.innerHTML = 'Copied!';
      setTimeout(() => {
        e.target.innerHTML = 'Copy!';
      }, 2000);
    }, false);
  }
}

const initTabButtons = () => {
  var fxcalc_tab_items = document.querySelectorAll('.fxcalc-tab-item a');
  fxcalc_tab_items.forEach(fxcalc_tab_item => {
    fxcalc_tab_item.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      fxcalc_tab_items.forEach(tb => {
        tb.parentElement.className = "fxcalc-tab-item";
      });
      e.target.parentElement.className = "fxcalc-tab-item fxcalc-active";

      document.querySelectorAll('.fxcalc-tabs-content').forEach(tbc => {
        if (tbc.getAttribute('data-id') === e.target.getAttribute('href').substr(1)) {
          tbc.style.display = "block";
        } else {
          tbc.style.display = "none";
        }
      });
    }, false);
  });
}

const getSettings = (calculator, setting) => {
  const inputName = `fxcalc_${calculator}_${setting}`;
  const suffix = setting === 'ads' ? '[]' : '';
  const selector = `[name="fxcalc_${calculator}_settings[${inputName}]${suffix}"]`;
  const inputs = document.querySelectorAll(selector);
  let input = inputs[0];
  if (inputs.length > 1) input = document.querySelector(`${selector}:checked`);
  if (setting === 'ads') return Array.from(inputs).filter(input => input.checked).map(input => input.value);
  if (input?.type === 'checkbox') return input.checked ? input.value : '';
  return input?.value || '';
};

const setSettings = (calculator, setting, value) => {
  const inputName = `fxcalc_${calculator}_${setting}`;
  const selector = `[name="fxcalc_${calculator}_settings[${inputName}]"]`;
  const inputs = document.querySelectorAll(selector);
  if (inputs.length > 1) {
    inputs.forEach(input => {
      if (input.value === value) {
        if (!input.checked) {
          input.checked = true;
          input.dispatchEvent(new Event('change'));
        }
      } else input.checked = false;
    });
  } else {
    if (inputs[0].value !== value) {
      inputs[0].value = value;
      inputs[0].dispatchEvent(new Event('change'));
    }
  }
}

const changeButtonActiveness = (calculator, disabled) => {
  document.querySelector("#fxcalc-" + calculator + "-tab").querySelectorAll("input[type=button], input[type=submit]").forEach(btn => {
    btn.disabled = disabled;
  });

  document.querySelector("#fxcalc-" + calculator + "-tab").querySelectorAll(".fxcalc-tip").forEach(tip => {
    tip.style.display = disabled ? "none" : "inline-block";
  });
}

const inputsUpdated = (calculator) => {
  const old_settings = fxcalcDbSettings[calculator];
  const current_settings = {};
  let changed = false;
  Object.keys(old_settings).forEach(key => {
    current_settings[key] = getSettings(calculator, key);
    changed = changed || JSON.stringify(old_settings[key]) !== JSON.stringify(current_settings[key]);
  });
  const disabled = !changed;
  changeButtonActiveness(calculator, disabled);
}

const updateIframeSize = (iframe) => {
  const calculator = iframe.getAttribute("data-calculator");
  const maxWidth = Number(iframe.getAttribute("data-max-width") || 484);
  const width = Math.min(maxWidth, iframe.parentElement.offsetWidth);
  if (!width || calculator == 'rrwinrate') return;
  iframe.width = width;
  let src = iframe.src;
  if (width < 720) src = iframe.src.split('mode=3').join('mode=2');
  else src = iframe.src.split('mode=2').join('mode=3');
  if (src !== iframe.src) iframe.src = src;
}

const updateIframeSizes = () => {
  calculators.forEach(calculator => {
    const iframes = document.querySelectorAll("iframe.fxcalc_" + calculator);
    iframes.forEach(updateIframeSize);
  });
}

const utoa = (str) => {
  return btoa(unescape(encodeURIComponent(str)));
}

const atou = (str) => {
  return encodeURIComponent(unescape(atob(str)));
}

const initEvents = () => {
  const calculatorTitleChanged = (calculator, title) => {
    const iframe = document.querySelector('iframe.fxcalc_' + calculator);
    const current_src = iframe.src;
    const regex = /([&?])title=[^&]*/gi;
    let src = current_src.replaceAll(regex, '');
    src = src + (src.includes('?') ? '&' : '?') + 'title=' + utoa(title);
    if (src !== iframe.src) iframe.src = src;
  }

  const calculatorLanguageChanged = (calculator, lang) => {
    const iframe = document.querySelector('iframe.fxcalc_' + calculator);
    const current_src = iframe.src;
    const regex = /([&?])lang=[^&]*/gi;
    let src = current_src.replaceAll(regex, '');
    src = src + (src.includes('?') ? '&' : '?') + 'lang=' + lang;
    if (src !== iframe.src) iframe.src = src;
  }

  const calculatorEsmaChanged = (calculator, esma) => {
    const iframe = document.querySelector('iframe.fxcalc_' + calculator);
    const current_src = iframe.src;
    const regex = /([&?])esma=[^&]*/gi;
    let src = current_src.replaceAll(regex, '');
    src = src + (src.includes('?') ? '&' : '?') + 'esma=' + esma;
    if (src !== iframe.src) iframe.src = src;
  }

  const calculatorDescChanged = (calculator, desc) => {
    const iframe = document.querySelector('iframe.fxcalc_' + calculator);
    const current_src = iframe.src;
    const regex = /([&?])desc=[^&]*/gi;
    let src = current_src.replaceAll(regex, '');
    src = src + (src.includes('?') ? '&' : '?') + 'desc=' + desc;
    if (src !== iframe.src) iframe.src = src;
  }

  const calculatorAdsChanged = (calculator, values) => {
    const iframe = document.querySelector('iframe.fxcalc_' + calculator);
    const current_src = iframe.src;
    const regex = /([&?])ads=[^&]*/gi;
    let src = current_src.replaceAll(regex, '');
    values.forEach(ad => src = src + '&ads=' + ad);
    if (src !== iframe.src) iframe.src = src;
  }

  document.querySelectorAll(".fxcalc-selectable-items input[type=radio]").forEach(radio => {
    radio.addEventListener("change", (e) => {
      const title = e.target.value;
      const name = e.target.name;

      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorTitleChanged(calculator, title);

      document.querySelectorAll('.fxcalc-tabs-content').forEach(tabContent => {
        if (tabContent.style.display === "block") {
          const titleAlignments = tabContent.querySelector(".fxcalc-title-alignments");
          const isCustomTitle = e.target.classList.contains("fxcalc-custom-title-radio");
          titleAlignments.style.display = (isCustomTitle || title.length) ? "flex" : "none";
        }
      });
    }, false);
  });

  document.querySelectorAll(".fxcalc-check-box-container.esma-checkbox input[type=checkbox]").forEach(input => {
    input.addEventListener("change", (e) => {
      const name = e.target.name;
      const value = e.target.checked ? e.target.value : '';
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorEsmaChanged(calculator, value);
    }, false);
  });

  document.querySelectorAll(".fxcalc-check-box-container.desc-checkbox input[type=checkbox]").forEach(input => {
    input.addEventListener("change", (e) => {
      const name = e.target.name;
      const value = e.target.checked ? e.target.value : '';
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorDescChanged(calculator, value);
    }, false);
  });

  document.querySelectorAll(".fxcalc-item-ads input[type=checkbox]").forEach(input => {
    input.addEventListener("change", (e) => {
      const checked = e.target.closest(".fxcalc-item-ads").querySelectorAll("input[type=checkbox]:checked");
      const values = Array.from(checked).map(checkbox => checkbox.value);
      const name = e.target.name;
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorAdsChanged(calculator, values);
    }, false);
  });

  document.querySelectorAll(".fxcalc-styling-options input[type=radio]").forEach(radio => {
    radio.addEventListener("change", (e) => {
      const mode = e.target.value;
      const name = e.target.name;
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      const iframe = document.querySelector('iframe.fxcalc_' + calculator);
      const current_src = iframe.src;
      const regex = /([&?])mode=[^&]*/gi;
      let src = current_src.replaceAll(regex, '');
      src = src + (src.includes('?') ? '&' : '?') + 'mode=' + mode;
      if (src !== iframe.src) iframe.src = src;
      let width = 484;
      const hintEl = document.querySelector('span.fxcalc-' + calculator + '-mode3-hint');
      if (Number(mode) === 3) {
        width = 800;
        hintEl.style.display = 'block';
      } else {
        hintEl.style.display = 'none';
      }
      iframe.width = width;
      iframe.setAttribute('data-max-width', width);
    }, false);
  });

  document.querySelectorAll(".fxcalc-custom-title-radio").forEach(customRadio => {
    customRadio.addEventListener("change", (e) => {
      customRadio.value = customRadio.parentElement.querySelector(".fxcalc-custom-title").value;
      const name = e.target.name;
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorTitleChanged(calculator, e.target.value);
    }, false);
  });

  const setOptionValue = (e) => {
    const el = e.target;
    el.parentElement.querySelector(".fxcalc-custom-title-radio").value = el.value;
    const radio = el.parentElement.querySelector(".fxcalc-custom-title-radio");
    if (!radio.checked && e.type === "focus") {
      radio.checked = true;
    }
    radio.value = el.value;
    var event = new Event('change');
    radio.dispatchEvent(event);
  }

  document.querySelectorAll(".fxcalc-custom-title").forEach(titleField => {
    titleField.addEventListener("focus", (e) => {
      setOptionValue(e);
    });
    titleField.addEventListener("blur", setOptionValue);
  });

  document.querySelectorAll(".fxcalc_title_alignment").forEach(input => {
    input.addEventListener("change", (e) => {
      const align = e.target.value;
      const name = e.target.name;
      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      const iframe = document.querySelector('iframe.fxcalc_' + calculator);
      const current_src = iframe.src;
      const regex = /([&?])align=[^&]*/gi;
      let src = current_src.replaceAll(regex, '');
      src = src + (src.includes('?') ? '&' : '?') + 'align=' + align;
      if (src !== iframe.src) iframe.src = src;

      document.querySelectorAll('.fxcalc-tabs-content').forEach(tabContent => {
        if (tabContent.style.display === "block") {
          tabContent.querySelectorAll(".fxcalc-align").forEach(d => {
            if (d.classList.contains("fxcalc-align-" + align))
              d.classList.add("active");
            else d.classList.remove("active");
          });
        }
      });
    });
  });

  document.querySelectorAll(".fxcalc-align").forEach(div => {
    div.addEventListener("click", function (e) {
      const el = this;
      const alignment = el.getAttribute("data-align");
      document.querySelectorAll('.fxcalc-tabs-content').forEach(tabContent => {
        if (tabContent.style.display === "block") {
          const input = tabContent.querySelector(".fxcalc_title_alignment");
          input.value = alignment;
          input.dispatchEvent(new Event('change'));
        }
      });
    });
  });

  document.querySelectorAll(".fxcalc-settings-form input, .fxcalc-settings-form select").forEach(inpt => {
    inpt.addEventListener("change", (e) => {
      let form = e.target;
      while (form.className.indexOf("fxcalc-settings-form") == -1) form = form.parentElement;
      const calculator = form.querySelector(".fxcalc-button-group").getAttribute('data-calculator');
      inputsUpdated(calculator);
    });
  });

  document.querySelectorAll(".fxcalc-select-language").forEach(sel => {
    sel.addEventListener("change", e => {
      const lang = e.target.value || "en";
      const name = e.target.name;

      const calculator = name.split("_settings")[0].split("fxcalc_")[1];
      calculatorLanguageChanged(calculator, lang);
    });
  });

  calculators.forEach(calculator => {
    const iframes = document.querySelectorAll("iframe.fxcalc_" + calculator);
    iframes.forEach(iframe => {
      iframe.addEventListener("load", e => updateIframeSize(e.target));
      respondToVisibility(iframe, (isVisible) => {
        if (isVisible) {
          updateIframeSize(iframe);
        }
      });
    });
  });

  jQuery(document).on("submit", ".fxcalc-settings-form", function (e) {
    e.preventDefault();
    e.stopPropagation();
    jQuery(this).find("input[type=submit]").prop("disabled", true);

    jQuery.ajax({
      type: "POST",
      data: jQuery(this).serialize(),
      dataType: "json",
      url: this.getAttribute("action"),
      success: response => {
        if (response.data && response.data.calculator) {
          const calculator = response.data.calculator;
          const data = response.data;
          fxcalcDbSettings[calculator] = {
            style_mode: data[`fxcalc_${calculator}_style_mode`],
            title: data[`fxcalc_${calculator}_title`],
            title_alignment: data[`fxcalc_${calculator}_title_alignment`],
            language: data[`fxcalc_${calculator}_language`],
            esma: data[`fxcalc_${calculator}_esma`] || '',
            desc: data[`fxcalc_${calculator}_desc`] || '',
            ads: data[`fxcalc_${calculator}_ads`] || []
          }
          inputsUpdated(calculator);
        }
        alert(response.success ? "Changes saved successfully!" : "Error saving changes!");
      }
    }).fail(function (data) {
      jQuery(this).find("input[type=submit]").prop("disabled", false);
      alert("Error saving changes! please try again...");
      console.log(data);
    });

    return false;
  });

  window.addEventListener("resize", updateIframeSizes);
  window.addEventListener("load", updateIframeSizes);
}

document.addEventListener('DOMContentLoaded', function () {
  initCopyButtons();
  initTabButtons();
  initEvents();
}, false);